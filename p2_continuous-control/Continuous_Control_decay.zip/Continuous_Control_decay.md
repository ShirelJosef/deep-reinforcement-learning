# Continuous Control

---

In this notebook, you will learn how to use the Unity ML-Agents environment for the second project of the [Deep Reinforcement Learning Nanodegree](https://www.udacity.com/course/deep-reinforcement-learning-nanodegree--nd893) program.

### 1. Start the Environment

We begin by importing the necessary packages.  If the code cell below returns an error, please revisit the project instructions to double-check that you have installed [Unity ML-Agents](https://github.com/Unity-Technologies/ml-agents/blob/master/docs/Installation.md) and [NumPy](http://www.numpy.org/).


```python
from unityagents import UnityEnvironment
import numpy as np
```

Next, we will start the environment!  **_Before running the code cell below_**, change the `file_name` parameter to match the location of the Unity environment that you downloaded.

- **Mac**: `"path/to/Reacher.app"`
- **Windows** (x86): `"path/to/Reacher_Windows_x86/Reacher.exe"`
- **Windows** (x86_64): `"path/to/Reacher_Windows_x86_64/Reacher.exe"`
- **Linux** (x86): `"path/to/Reacher_Linux/Reacher.x86"`
- **Linux** (x86_64): `"path/to/Reacher_Linux/Reacher.x86_64"`
- **Linux** (x86, headless): `"path/to/Reacher_Linux_NoVis/Reacher.x86"`
- **Linux** (x86_64, headless): `"path/to/Reacher_Linux_NoVis/Reacher.x86_64"`

For instance, if you are using a Mac, then you downloaded `Reacher.app`.  If this file is in the same folder as the notebook, then the line below should appear as follows:
```
env = UnityEnvironment(file_name="Reacher.app")
```


```python
env = UnityEnvironment(file_name="./Reacher_Linux_NoVis/Reacher.x86_64", base_port=64738)
```

    INFO:unityagents:
    'Academy' started successfully!
    Unity Academy name: Academy
            Number of Brains: 1
            Number of External Brains : 1
            Lesson number : 0
            Reset Parameters :
    		goal_size -> 5.0
    		goal_speed -> 1.0
    Unity brain name: ReacherBrain
            Number of Visual Observations (per agent): 0
            Vector Observation space type: continuous
            Vector Observation space size (per agent): 33
            Number of stacked Vector Observation: 1
            Vector Action space type: continuous
            Vector Action space size (per agent): 4
            Vector Action descriptions: , , , 


Environments contain **_brains_** which are responsible for deciding the actions of their associated agents. Here we check for the first brain available, and set it as the default brain we will be controlling from Python.


```python
# get the default brain
brain_name = env.brain_names[0]
brain = env.brains[brain_name]
```

### 2. Examine the State and Action Spaces

In this environment, a double-jointed arm can move to target locations. A reward of `+0.1` is provided for each step that the agent's hand is in the goal location. Thus, the goal of your agent is to maintain its position at the target location for as many time steps as possible.

The observation space consists of `33` variables corresponding to position, rotation, velocity, and angular velocities of the arm.  Each action is a vector with four numbers, corresponding to torque applicable to two joints.  Every entry in the action vector must be a number between `-1` and `1`.

Run the code cell below to print some information about the environment.


```python
# reset the environment
env_info = env.reset(train_mode=True)[brain_name]

# number of agents
num_agents = len(env_info.agents)
print('Number of agents:', num_agents)

# size of each action
action_size = brain.vector_action_space_size
print('Size of each action:', action_size)

# examine the state space 
states = env_info.vector_observations
state_size = states.shape[1]
print('There are {} agents. Each observes a state with length: {}'.format(states.shape[0], state_size))
print('The state for the first agent looks like:', states[0])
```

    Number of agents: 20
    Size of each action: 4
    There are 20 agents. Each observes a state with length: 33
    The state for the first agent looks like: [ 0.00000000e+00 -4.00000000e+00  0.00000000e+00  1.00000000e+00
     -0.00000000e+00 -0.00000000e+00 -4.37113883e-08  0.00000000e+00
      0.00000000e+00  0.00000000e+00  0.00000000e+00  0.00000000e+00
      0.00000000e+00  0.00000000e+00 -1.00000000e+01  0.00000000e+00
      1.00000000e+00 -0.00000000e+00 -0.00000000e+00 -4.37113883e-08
      0.00000000e+00  0.00000000e+00  0.00000000e+00  0.00000000e+00
      0.00000000e+00  0.00000000e+00  5.75471878e+00 -1.00000000e+00
      5.55726624e+00  0.00000000e+00  1.00000000e+00  0.00000000e+00
     -1.68164849e-01]


### 3. Take Random Actions in the Environment

In the next code cell, you will learn how to use the Python API to control the agent and receive feedback from the environment.

Once this cell is executed, you will watch the agent's performance, if it selects an action at random with each time step.  A window should pop up that allows you to observe the agent, as it moves through the environment.  

Of course, as part of the project, you'll have to change the code so that the agent is able to use its experience to gradually choose better actions when interacting with the environment!


```python
'''env_info = env.reset(train_mode=False)[brain_name]     # reset the environment    
states = env_info.vector_observations                  # get the current state (for each agent)
scores = np.zeros(num_agents)                          # initialize the score (for each agent)
while True:
    actions = np.random.randn(num_agents, action_size) # select an action (for each agent)
    actions = np.clip(actions, -1, 1)                  # all actions between -1 and 1
    env_info = env.step(actions)[brain_name]           # send all actions to tne environment
    next_states = env_info.vector_observations         # get next state (for each agent)
    rewards = env_info.rewards                         # get reward (for each agent)
    dones = env_info.local_done                        # see if episode finished
    scores += env_info.rewards                         # update the score (for each agent)
    states = next_states                               # roll over states to next time step
    if np.any(dones):                                  # exit loop if episode finished
        break
print('Total score (averaged over agents) this episode: {}'.format(np.mean(scores)))'''
```




    "env_info = env.reset(train_mode=False)[brain_name]     # reset the environment    \nstates = env_info.vector_observations                  # get the current state (for each agent)\nscores = np.zeros(num_agents)                          # initialize the score (for each agent)\nwhile True:\n    actions = np.random.randn(num_agents, action_size) # select an action (for each agent)\n    actions = np.clip(actions, -1, 1)                  # all actions between -1 and 1\n    env_info = env.step(actions)[brain_name]           # send all actions to tne environment\n    next_states = env_info.vector_observations         # get next state (for each agent)\n    rewards = env_info.rewards                         # get reward (for each agent)\n    dones = env_info.local_done                        # see if episode finished\n    scores += env_info.rewards                         # update the score (for each agent)\n    states = next_states                               # roll over states to next time step\n    if np.any(dones):                                  # exit loop if episode finished\n        break\nprint('Total score (averaged over agents) this episode: {}'.format(np.mean(scores)))"



When finished, you can close the environment.


```python
#env.close()
```

### 4. It's Your Turn!

Now it's your turn to train your own agent to solve the environment!  When training the environment, set `train_mode=True`, so that the line for resetting the environment looks like the following:
```python
env_info = env.reset(train_mode=True)[brain_name]
```


```python
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

def hidden_init(layer):
    fan_in = layer.weight.data.size()[0]
    lim = 1. / np.sqrt(fan_in)
    return (-lim, lim)

class Actor(nn.Module):
    """Actor (Policy) Model."""

    def __init__(self, state_size, action_size, seed, fc_units=256):
        """Initialize parameters and build model.
        Params
        ======
            state_size (int): Dimension of each state
            action_size (int): Dimension of each action
            seed (int): Random seed
            fc1_units (int): Number of nodes in first hidden layer
            fc2_units (int): Number of nodes in second hidden layer
        """
        super(Actor, self).__init__()
        self.seed = torch.manual_seed(seed)
        self.fc1 = nn.Linear(state_size, fc_units)
        self.fc2 = nn.Linear(fc_units, action_size)
        self.reset_parameters()

    def reset_parameters(self):
        self.fc1.weight.data.uniform_(*hidden_init(self.fc1))
        self.fc2.weight.data.uniform_(-3e-3, 3e-3)

    def forward(self, state):
        """Build an actor (policy) network that maps states -> actions."""
        x = F.relu(self.fc1(state))
        return F.tanh(self.fc2(x))


class Critic(nn.Module):
    """Critic (Value) Model."""

    def __init__(self, state_size, action_size, seed, fcs1_units=256, fc2_units=256, fc3_units=128):
        """Initialize parameters and build model.
        Params
        ======
            state_size (int): Dimension of each state
            action_size (int): Dimension of each action
            seed (int): Random seed
            fcs1_units (int): Number of nodes in the first hidden layer
            fc2_units (int): Number of nodes in the second hidden layer
        """
        super(Critic, self).__init__()
        self.seed = torch.manual_seed(seed)
        self.fcs1 = nn.Linear(state_size, fcs1_units)
        self.fc2 = nn.Linear(fcs1_units+action_size, fc2_units)
        self.fc3 = nn.Linear(fc2_units, fc3_units)
        self.fc4 = nn.Linear(fc3_units, 1)
        self.reset_parameters()

    def reset_parameters(self):
        self.fcs1.weight.data.uniform_(*hidden_init(self.fcs1))
        self.fc2.weight.data.uniform_(*hidden_init(self.fc2))
        self.fc3.weight.data.uniform_(*hidden_init(self.fc3))
        self.fc4.weight.data.uniform_(-3e-3, 3e-3)

    def forward(self, state, action):
        """Build a critic (value) network that maps (state, action) pairs -> Q-values."""
        xs = F.leaky_relu(self.fcs1(state))
        x = torch.cat((xs, action), dim=1)
        x = F.leaky_relu(self.fc2(x))
        x = F.leaky_relu(self.fc3(x))
        return self.fc4(x)

```


```python
import numpy as np
import random
import copy
from collections import namedtuple, deque

import torch
import torch.nn.functional as F
import torch.optim as optim

BUFFER_SIZE = int(1e6)  # replay buffer size
BATCH_SIZE = 128        # minibatch size
GAMMA = 0.99            # discount factor
TAU = 1e-3              # for soft update of target parameters
LR_ACTOR = 1e-4         # learning rate of the actor 
LR_CRITIC = 3e-4        # learning rate of the critic
WEIGHT_DECAY = 0.0001   # L2 weight decay
START_EPS = 1.0
END_EPS = 0.1

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class Agent():
    """Interacts with and learns from the environment."""
    
    def __init__(self, state_size, action_size, random_seed,number_of_agents):
        """Initialize an Agent object.
        
        Params
        ======
            state_size (int): dimension of each state
            action_size (int): dimension of each action
            random_seed (int): random seed
        """
        self.state_size = state_size
        self.action_size = action_size
        self.seed = random.seed(random_seed)

        # Actor Network (w/ Target Network)
        self.actor_local = Actor(state_size, action_size, random_seed).to(device)
        self.actor_target = Actor(state_size, action_size, random_seed).to(device)
        self.actor_optimizer = optim.Adam(self.actor_local.parameters(), lr=LR_ACTOR)

        # Critic Network (w/ Target Network)
        self.critic_local = Critic(state_size, action_size, random_seed).to(device)
        self.critic_target = Critic(state_size, action_size, random_seed).to(device)
        self.critic_optimizer = optim.Adam(self.critic_local.parameters(), lr=LR_CRITIC)#, weight_decay=WEIGHT_DECAY)

        # Noise process
        #self.noise = OUNoise(action_size, random_seed)
        self.noise = OrnsteinUhlenbeckProcess(action_size)

        # Replay memory
        self.memory = ReplayBuffer(action_size, BUFFER_SIZE, BATCH_SIZE, random_seed)
        
        # number of agents
        self.number_of_agents = number_of_agents
        
        self.current_eps = START_EPS
    
    def step(self, state, action, reward, next_state, done):
        """Save experience in replay memory, and use random sample from buffer to learn."""
        
        assert len(state) == (self.number_of_agents)
        # Save experience / reward
        for i in range(len(state)):
            self.memory.add(state[i], action[i], reward[i], next_state[i], done)

        # Learn, if enough samples are available in memory
        if len(self.memory) > BATCH_SIZE:
            experiences = self.memory.sample()
            self.learn(experiences, GAMMA)

    def act(self, state, step, add_noise=True):
        """Returns actions for given state as per current policy."""
        state = torch.from_numpy(state).float().to(device)
        self.actor_local.eval()
        with torch.no_grad():
            action = self.actor_local(state).cpu().data.numpy()
        self.actor_local.train()
        if add_noise:
            self.current_eps = max(END_EPS,self.current_eps-(START_EPS-END_EPS)/50000)
            #print(self.current_eps)
            action += (self.noise.sample() * self.current_eps)
        return np.clip(action, -1, 1)

    def reset(self):
        self.noise.reset()

    def learn(self, experiences, gamma):
        """Update policy and value parameters using given batch of experience tuples.
        Q_targets = r + γ * critic_target(next_state, actor_target(next_state))
        where:
            actor_target(state) -> action
            critic_target(state, action) -> Q-value

        Params
        ======
            experiences (Tuple[torch.Tensor]): tuple of (s, a, r, s', done) tuples 
            gamma (float): discount factor
        """
        states, actions, rewards, next_states, dones = experiences

        # ---------------------------- update critic ---------------------------- #
        # Get predicted next-state actions and Q values from target models
        actions_next = self.actor_target(next_states)
        Q_targets_next = self.critic_target(next_states, actions_next)
        # Compute Q targets for current states (y_i)
        Q_targets = rewards + (gamma * Q_targets_next * (1 - dones))
        # Compute critic loss
        Q_expected = self.critic_local(states, actions)
        critic_loss = F.mse_loss(Q_expected, Q_targets)
        # Minimize the loss
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # ---------------------------- update actor ---------------------------- #
        # Compute actor loss
        actions_pred = self.actor_local(states)
        actor_loss = -self.critic_local(states, actions_pred).mean()
        # Minimize the loss
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # ----------------------- update target networks ----------------------- #
        self.soft_update(self.critic_local, self.critic_target, TAU)
        self.soft_update(self.actor_local, self.actor_target, TAU)                     

    def soft_update(self, local_model, target_model, tau):
        """Soft update model parameters.
        θ_target = τ*θ_local + (1 - τ)*θ_target

        Params
        ======
            local_model: PyTorch model (weights will be copied from)
            target_model: PyTorch model (weights will be copied to)
            tau (float): interpolation parameter 
        """
        for target_param, local_param in zip(target_model.parameters(), local_model.parameters()):
            target_param.data.copy_(tau*local_param.data + (1.0-tau)*target_param.data)

class OUNoise:
    """Ornstein-Uhlenbeck process."""

    def __init__(self, size, seed, mu=0., theta=0.15, sigma=0.2):
        """Initialize parameters and noise process."""
        self.mu = mu * np.ones(size)
        self.theta = theta
        self.sigma = sigma
        self.seed = random.seed(seed)
        self.reset()

    def reset(self):
        """Reset the internal state (= noise) to mean (mu)."""
        self.state = copy.copy(self.mu)

    def sample(self):
        """Update internal state and return it as a noise sample."""
        x = self.state
        dx = self.theta * (self.mu - x) + self.sigma * np.array([random.random() for i in range(len(x))])
        self.state = x + dx
        return self.state

class OrnsteinUhlenbeckProcess():
    def __init__(self, size, std=0.2, theta=.15, dt=1e-2, x0=None):
        self.theta = theta
        self.mu = 0
        self.std = std
        self.dt = dt
        self.x0 = x0
        self.size = size
        self.reset()

    def sample(self):
        x = self.x_prev + self.theta * (self.mu - self.x_prev) * self.dt + self.std * np.sqrt(self.dt) * np.random.randn(self.size)
        self.x_prev = x
        return x

    def reset(self):
        self.x_prev = self.x0 if self.x0 is not None else np.zeros(self.size)
    
class ReplayBuffer:
    """Fixed-size buffer to store experience tuples."""

    def __init__(self, action_size, buffer_size, batch_size, seed):
        """Initialize a ReplayBuffer object.
        Params
        ======
            buffer_size (int): maximum size of buffer
            batch_size (int): size of each training batch
        """
        self.action_size = action_size
        self.memory = deque(maxlen=buffer_size)  # internal memory (deque)
        self.batch_size = batch_size
        self.experience = namedtuple("Experience", field_names=["state", "action", "reward", "next_state", "done"])
        self.seed = random.seed(seed)
    
    def add(self, state, action, reward, next_state, done):
        """Add a new experience to memory."""
        e = self.experience(state, action, reward, next_state, done)
        self.memory.append(e)
    
    def sample(self):
        """Randomly sample a batch of experiences from memory."""
        experiences = random.sample(self.memory, k=self.batch_size)

        states = torch.from_numpy(np.vstack([e.state for e in experiences if e is not None])).float().to(device)
        actions = torch.from_numpy(np.vstack([e.action for e in experiences if e is not None])).float().to(device)
        rewards = torch.from_numpy(np.vstack([e.reward for e in experiences if e is not None])).float().to(device)
        next_states = torch.from_numpy(np.vstack([e.next_state for e in experiences if e is not None])).float().to(device)
        dones = torch.from_numpy(np.vstack([e.done for e in experiences if e is not None]).astype(np.uint8)).float().to(device)

        return (states, actions, rewards, next_states, dones)

    def __len__(self):
        """Return the current size of internal memory."""
        return len(self.memory)
```


```python
import matplotlib.pyplot as plt

agent = Agent(state_size=33, action_size=4, random_seed=2,number_of_agents=20)

print(env.brain_names)
brain_name = env.brain_names[0]
print(env.brains)
brain = env.brains[brain_name]

#def ddpg(n_episodes=1, max_t=300, print_every=100):
def ddpg(n_episodes=2000, max_t=300, print_every=1):
    scores_window = deque(maxlen=100)  # last 100 scores
    scores = []
    step_counter = 0
    for i_episode in range(1, n_episodes+1):
        env_info = env.reset(train_mode=True)[brain_name]
        states = env_info.vector_observations
        #print("states shape:" +str(states.shape))
        agent.reset()
        current_scores = np.zeros(num_agents)
        while True:
            step_counter = step_counter + 1
            actions = agent.act(states,step_counter)
            #print(actions)
            actions = np.clip(actions, -1, 1)
            env_info = env.step(actions)[brain_name]
            next_states = env_info.vector_observations         # get next state (for each agent)
            rewards = env_info.rewards                         # get reward (for each agent)
            dones = env_info.local_done                        # see if episode finished
            agent.step(states, actions, rewards, next_states, dones)
            states = next_states
            #print(agent.memory.__len__())
            current_scores += env_info.rewards
            #print(t)
            if np.any(dones):                                  # exit loop if episode finished
                break
            #next_state, reward, done, _ = env.step(action)
            #agent.step(state, action, reward, next_state, done)
            #state = next_state
            #score += reward
            #if done:
            #    break 
        scores_window.append(np.mean(current_scores))
        scores.append(np.mean(current_scores))              # save most recent score
        #print('\rEpisode {}\tAverage Score: {:.2f}'.format(i_episode, np.mean(scores_window)), end="")
        #print("epsilon: "+str(agent.current_eps))
        if i_episode % print_every == 0:
            print('\rEpisode {}\tAverage Score: {:.2f}'.format(i_episode, np.mean(scores_window)))
            print("epsilon: "+str(agent.current_eps))
        if np.mean(scores_window)>=30.0:
            print('\nEnvironment solved in {:d} episodes!\tAverage Score: {:.2f}'.format(i_episode-100, np.mean(scores_window)))
            torch.save(agent.actor_local.state_dict(), 'checkpoint_actor_v1.pth')
            torch.save(agent.critic_local.state_dict(), 'checkpoint_critic_v1.pth')
            break
    return scores

scores = ddpg()

fig = plt.figure()
ax = fig.add_subplot(111)
plt.plot(np.arange(1, len(scores)+1), scores)
plt.ylabel('Score')
plt.xlabel('Episode #')
plt.show()
```

    ['ReacherBrain']
    {'ReacherBrain': <unityagents.brain.BrainParameters object at 0x7ff2a5467cf8>}
    Episode 1	Average Score: 0.54
    epsilon: 0.9819820000000375
    Episode 2	Average Score: 0.62
    epsilon: 0.9639640000000751
    Episode 3	Average Score: 0.71
    epsilon: 0.9459460000001126
    Episode 4	Average Score: 0.78
    epsilon: 0.9279280000001502
    Episode 5	Average Score: 0.87
    epsilon: 0.9099100000001877
    Episode 6	Average Score: 0.96
    epsilon: 0.8918920000002253
    Episode 7	Average Score: 1.00
    epsilon: 0.8738740000002628
    Episode 8	Average Score: 1.03
    epsilon: 0.8558560000003004
    Episode 9	Average Score: 1.08
    epsilon: 0.8378380000003379
    Episode 10	Average Score: 1.21
    epsilon: 0.8198200000003755
    Episode 11	Average Score: 1.29
    epsilon: 0.801802000000413
    Episode 12	Average Score: 1.38
    epsilon: 0.7837840000004506
    Episode 13	Average Score: 1.48
    epsilon: 0.7657660000004881
    Episode 14	Average Score: 1.63
    epsilon: 0.7477480000005257
    Episode 15	Average Score: 1.77
    epsilon: 0.7297300000005632
    Episode 16	Average Score: 1.90
    epsilon: 0.7117120000006008
    Episode 17	Average Score: 2.03
    epsilon: 0.6936940000006383
    Episode 18	Average Score: 2.14
    epsilon: 0.6756760000006758
    Episode 19	Average Score: 2.28
    epsilon: 0.6576580000007134
    Episode 20	Average Score: 2.38
    epsilon: 0.6396400000007509
    Episode 21	Average Score: 2.53
    epsilon: 0.6216220000007885
    Episode 22	Average Score: 2.66
    epsilon: 0.603604000000826
    Episode 23	Average Score: 2.80
    epsilon: 0.5855860000008636
    Episode 24	Average Score: 2.93
    epsilon: 0.5675680000009011
    Episode 25	Average Score: 3.09
    epsilon: 0.5495500000009387
    Episode 26	Average Score: 3.26
    epsilon: 0.5315320000009762
    Episode 27	Average Score: 3.42
    epsilon: 0.5135140000010138
    Episode 28	Average Score: 3.59
    epsilon: 0.4954960000010374
    Episode 29	Average Score: 3.77
    epsilon: 0.47747800000101936
    Episode 30	Average Score: 3.96
    epsilon: 0.45946000000100135
    Episode 31	Average Score: 4.13
    epsilon: 0.4414420000009833
    Episode 32	Average Score: 4.30
    epsilon: 0.4234240000009653
    Episode 33	Average Score: 4.52
    epsilon: 0.4054060000009473
    Episode 34	Average Score: 4.70
    epsilon: 0.38738800000092927
    Episode 35	Average Score: 4.88
    epsilon: 0.36937000000091125
    Episode 36	Average Score: 5.05
    epsilon: 0.3513520000008932
    Episode 37	Average Score: 5.26
    epsilon: 0.3333340000008752
    Episode 38	Average Score: 5.50
    epsilon: 0.3153160000008572
    Episode 39	Average Score: 5.73
    epsilon: 0.29729800000083917
    Episode 40	Average Score: 5.92
    epsilon: 0.27928000000082115
    Episode 41	Average Score: 6.10
    epsilon: 0.26126200000080313
    Episode 42	Average Score: 6.30
    epsilon: 0.24324400000079555
    Episode 43	Average Score: 6.51
    epsilon: 0.2252260000008053
    Episode 44	Average Score: 6.72
    epsilon: 0.20720800000081507
    Episode 45	Average Score: 6.93
    epsilon: 0.18919000000082484
    Episode 46	Average Score: 7.15
    epsilon: 0.1711720000008346
    Episode 47	Average Score: 7.41
    epsilon: 0.15315400000084436
    Episode 48	Average Score: 7.62
    epsilon: 0.13513600000085413
    Episode 49	Average Score: 7.80
    epsilon: 0.11711800000085781
    Episode 50	Average Score: 7.98
    epsilon: 0.1
    Episode 51	Average Score: 8.18
    epsilon: 0.1
    Episode 52	Average Score: 8.41
    epsilon: 0.1
    Episode 53	Average Score: 8.60
    epsilon: 0.1
    Episode 54	Average Score: 8.82
    epsilon: 0.1
    Episode 55	Average Score: 9.03
    epsilon: 0.1
    Episode 56	Average Score: 9.24
    epsilon: 0.1
    Episode 57	Average Score: 9.40
    epsilon: 0.1
    Episode 58	Average Score: 9.58
    epsilon: 0.1
    Episode 59	Average Score: 9.76
    epsilon: 0.1
    Episode 60	Average Score: 9.97
    epsilon: 0.1
    Episode 61	Average Score: 10.17
    epsilon: 0.1
    Episode 62	Average Score: 10.38
    epsilon: 0.1
    Episode 63	Average Score: 10.56
    epsilon: 0.1
    Episode 64	Average Score: 10.72
    epsilon: 0.1
    Episode 65	Average Score: 10.91
    epsilon: 0.1
    Episode 66	Average Score: 11.09
    epsilon: 0.1
    Episode 67	Average Score: 11.28
    epsilon: 0.1
    Episode 68	Average Score: 11.44
    epsilon: 0.1
    Episode 69	Average Score: 11.62
    epsilon: 0.1
    Episode 70	Average Score: 11.77
    epsilon: 0.1
    Episode 71	Average Score: 11.97
    epsilon: 0.1
    Episode 72	Average Score: 12.16
    epsilon: 0.1
    Episode 73	Average Score: 12.33
    epsilon: 0.1
    Episode 74	Average Score: 12.49
    epsilon: 0.1
    Episode 75	Average Score: 12.64
    epsilon: 0.1
    Episode 76	Average Score: 12.79
    epsilon: 0.1
    Episode 77	Average Score: 12.96
    epsilon: 0.1
    Episode 78	Average Score: 13.11
    epsilon: 0.1
    Episode 79	Average Score: 13.28
    epsilon: 0.1
    Episode 80	Average Score: 13.44
    epsilon: 0.1
    Episode 81	Average Score: 13.61
    epsilon: 0.1
    Episode 82	Average Score: 13.77
    epsilon: 0.1
    Episode 83	Average Score: 13.93
    epsilon: 0.1
    Episode 84	Average Score: 14.08
    epsilon: 0.1
    Episode 85	Average Score: 14.22
    epsilon: 0.1
    Episode 86	Average Score: 14.38
    epsilon: 0.1
    Episode 87	Average Score: 14.54
    epsilon: 0.1
    Episode 88	Average Score: 14.68
    epsilon: 0.1
    Episode 89	Average Score: 14.83
    epsilon: 0.1
    Episode 90	Average Score: 14.98
    epsilon: 0.1
    Episode 91	Average Score: 15.12
    epsilon: 0.1
    Episode 92	Average Score: 15.29
    epsilon: 0.1
    Episode 93	Average Score: 15.44
    epsilon: 0.1
    Episode 94	Average Score: 15.62
    epsilon: 0.1
    Episode 95	Average Score: 15.78
    epsilon: 0.1
    Episode 96	Average Score: 15.94
    epsilon: 0.1
    Episode 97	Average Score: 16.08
    epsilon: 0.1
    Episode 98	Average Score: 16.21
    epsilon: 0.1
    Episode 99	Average Score: 16.35
    epsilon: 0.1
    Episode 100	Average Score: 16.48
    epsilon: 0.1
    Episode 101	Average Score: 16.78
    epsilon: 0.1
    Episode 102	Average Score: 17.09
    epsilon: 0.1
    Episode 103	Average Score: 17.39
    epsilon: 0.1
    Episode 104	Average Score: 17.68
    epsilon: 0.1
    Episode 105	Average Score: 17.96
    epsilon: 0.1
    Episode 106	Average Score: 18.24
    epsilon: 0.1
    Episode 107	Average Score: 18.52
    epsilon: 0.1
    Episode 108	Average Score: 18.80
    epsilon: 0.1
    Episode 109	Average Score: 19.07
    epsilon: 0.1
    Episode 110	Average Score: 19.36
    epsilon: 0.1
    Episode 111	Average Score: 19.62
    epsilon: 0.1
    Episode 112	Average Score: 19.87
    epsilon: 0.1
    Episode 113	Average Score: 20.12
    epsilon: 0.1
    Episode 114	Average Score: 20.37
    epsilon: 0.1
    Episode 115	Average Score: 20.62
    epsilon: 0.1
    Episode 116	Average Score: 20.90
    epsilon: 0.1
    Episode 117	Average Score: 21.17
    epsilon: 0.1
    Episode 118	Average Score: 21.43
    epsilon: 0.1
    Episode 119	Average Score: 21.70
    epsilon: 0.1
    Episode 120	Average Score: 21.97
    epsilon: 0.1
    Episode 121	Average Score: 22.22
    epsilon: 0.1
    Episode 122	Average Score: 22.47
    epsilon: 0.1
    Episode 123	Average Score: 22.73
    epsilon: 0.1
    Episode 124	Average Score: 22.96
    epsilon: 0.1
    Episode 125	Average Score: 23.22
    epsilon: 0.1
    Episode 126	Average Score: 23.46
    epsilon: 0.1
    Episode 127	Average Score: 23.71
    epsilon: 0.1
    Episode 128	Average Score: 23.94
    epsilon: 0.1
    Episode 129	Average Score: 24.18
    epsilon: 0.1
    Episode 130	Average Score: 24.40
    epsilon: 0.1
    Episode 131	Average Score: 24.60
    epsilon: 0.1
    Episode 132	Average Score: 24.84
    epsilon: 0.1
    Episode 133	Average Score: 25.04
    epsilon: 0.1
    Episode 134	Average Score: 25.25
    epsilon: 0.1
    Episode 135	Average Score: 25.46
    epsilon: 0.1
    Episode 136	Average Score: 25.67
    epsilon: 0.1
    Episode 137	Average Score: 25.85
    epsilon: 0.1
    Episode 138	Average Score: 26.01
    epsilon: 0.1
    Episode 139	Average Score: 26.18
    epsilon: 0.1
    Episode 140	Average Score: 26.37
    epsilon: 0.1
    Episode 141	Average Score: 26.54
    epsilon: 0.1
    Episode 142	Average Score: 26.69
    epsilon: 0.1
    Episode 143	Average Score: 26.87
    epsilon: 0.1
    Episode 144	Average Score: 27.03
    epsilon: 0.1
    Episode 145	Average Score: 27.18
    epsilon: 0.1
    Episode 146	Average Score: 27.33
    epsilon: 0.1
    Episode 147	Average Score: 27.44
    epsilon: 0.1
    Episode 148	Average Score: 27.58
    epsilon: 0.1
    Episode 149	Average Score: 27.73
    epsilon: 0.1
    Episode 150	Average Score: 27.88
    epsilon: 0.1
    Episode 151	Average Score: 28.02
    epsilon: 0.1
    Episode 152	Average Score: 28.13
    epsilon: 0.1
    Episode 153	Average Score: 28.26
    epsilon: 0.1
    Episode 154	Average Score: 28.37
    epsilon: 0.1
    Episode 155	Average Score: 28.49
    epsilon: 0.1
    Episode 156	Average Score: 28.62
    epsilon: 0.1
    Episode 157	Average Score: 28.77
    epsilon: 0.1
    Episode 158	Average Score: 28.90
    epsilon: 0.1
    Episode 159	Average Score: 29.01
    epsilon: 0.1
    Episode 160	Average Score: 29.05
    epsilon: 0.1
    Episode 161	Average Score: 29.13
    epsilon: 0.1
    Episode 162	Average Score: 29.21
    epsilon: 0.1
    Episode 163	Average Score: 29.33
    epsilon: 0.1
    Episode 164	Average Score: 29.46
    epsilon: 0.1
    Episode 165	Average Score: 29.54
    epsilon: 0.1
    Episode 166	Average Score: 29.65
    epsilon: 0.1
    Episode 167	Average Score: 29.74
    epsilon: 0.1
    Episode 168	Average Score: 29.83
    epsilon: 0.1
    Episode 169	Average Score: 29.94
    epsilon: 0.1
    Episode 170	Average Score: 30.07
    epsilon: 0.1
    
    Environment solved in 70 episodes!	Average Score: 30.07



    
![png](output_15_1.png)
    

